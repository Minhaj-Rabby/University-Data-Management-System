package universitydata.subject;

import universitydata.department.Department;

public class Subject extends Department
{

	private String subjectname;
	private String subjectcode;
	private int maxtheorymarks=0;
	private int maxothermarks=0;
	private String subjecttype;
	
	
	public void setSubjectType(String subjecttype)
	{
		this.subjecttype=subjecttype;
	}
	public void setMaxTheoryMarks(int maxtheorymarks)
	{
		this.maxtheorymarks=maxtheorymarks;
	}
	public void setMaxOtherMarks(int maxothermarks)
	{
		this.maxothermarks=maxothermarks;
	}
	public void setSubjectName(String subject)
	{
		this.subjectname=subject;
	}
	public void setSubjectCode(String subjectcode)
	{
		this.subjectcode=subjectcode;
	}
	public void setSemorYear(int semoryear)
	{
		super.setSemorYear(semoryear);
	}
	public String getSubjectCode()
	{
		return subjectcode;
	}
	public String getSubjectName()
	{
		return subjectname;
	}
	public int getMaxTheoryMarks()
	{
		return maxtheorymarks;
	}
	public int getMaxOtherMarks()
	{
		return maxothermarks;
	}
	public String getSubjectType()
	{
		return subjecttype;
	}
}
